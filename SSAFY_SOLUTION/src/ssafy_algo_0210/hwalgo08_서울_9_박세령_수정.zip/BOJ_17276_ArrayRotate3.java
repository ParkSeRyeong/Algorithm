package ssafy_algo_0210;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class BOJ_17276_ArrayRotate3 {
	static int[][] original;
	static int[][] move;
	static int[][] rotate;
	static int N;
	static int M;

	public static void print(int[][] printArr) {
		for (int[] i : printArr) {
			for (int j : i) {
				System.out.print(j + " ");
			}
			System.out.println();
		}
	}

	public static void No_1_Updown() {
		for (int i = 0; i < N / 2; i++) {
			for (int j = 0; j < M; j++) {
				int tmp = original[i][j];
				original[i][j] = original[N - i - 1][j];
				original[N - 1 - i][j] = tmp;
			}
		}
	}

	public static void No_2_Leftright() {
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < M / 2; j++) {
				int tmp = original[i][j];
				original[i][j] = original[i][M - 1 - j];
				original[i][M - 1 - j] = tmp;
			}
		}
	}

	public static void No_3_Right90() {
		for (int j = 0; j < M; j++) {
			for (int i = 0; i < N; i++) {
				rotate[j][N - 1 - i] = original[i][j];
			}
		}
	}

	public static void No_4_Left90() {
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < M; j++) {
				rotate[M - 1 - j][i] = original[i][j];
			}
		}
	}

	public static void No_5_Powerset() {
		int[][] powerset = new int[N / 2][M / 2];
		for (int i = 0; i < N / 2; i++) {
			System.arraycopy(original[i], 0, move[i], M / 2, M / 2);
			System.arraycopy(original[i], M / 2, move[N / 2 + i], M / 2, M / 2);
			System.arraycopy(original[N / 2 + i], M / 2, move[N / 2 + i], 0, M / 2);
			System.arraycopy(original[N / 2 + i], 0, move[i], 0, M / 2);
		}
		for (int i = 0; i < N; i++) {
			System.arraycopy(move[i], 0, original, 0, M);
		}
	}

	public static void No_6_Powerset_Reverse() {
		for (int i = 0; i < N / 2; i++) {
			System.arraycopy(original[i], 0, move[N / 2 + i], 0, M / 2);
			System.arraycopy(original[N / 2 + i], 0, move[N / 2 + i], M / 2, M / 2);
			System.arraycopy(original[N / 2 + i], M / 2, move[i], M / 2, M / 2);
			System.arraycopy(original[i], M / 2, move[i], 0, M / 2);
		}
		for (int i = 0; i < N; i++) {
			System.arraycopy(move[i], 0, original, 0, M);
		}
	}

	public static void main(String[] args) throws NumberFormatException, IOException {
		// 배열 받아오기
		// 회전해서 출력할 배열 하나 더 만들기
		System.setIn(new FileInputStream("src/ssafy_algo_0210/rotate3_test.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		String tmp = br.readLine();
		N = Integer.parseInt(tmp.split(" ")[0]);
		M = Integer.parseInt(tmp.split(" ")[1]);
		int R = Integer.parseInt(tmp.split(" ")[2]);

		original = new int[N][M];
		move = new int[N][M];
		rotate = new int[M][N];
		for (int i = 0; i < N; i++) {
			tmp = br.readLine();
			original[i] = Arrays.stream(tmp.split(" ")).mapToInt(Integer::parseInt).toArray();
		}
		// No_1_Updown();
		// No_2_Leftright();
		// No_3_Right90();
		// No_4_Left90();
		// No_5_Powerset();
		// No_6_Powerset_Reverse();
		int[][] forPrint;
		for (int i = 0; i < R; i++) {
			int[] choice = Arrays.stream(br.readLine().split(" ")).mapToInt(Integer::parseInt).toArray();
			for (int k : choice) {
				switch (k) {
				case 1:
					No_1_Updown();
					break;
				case 2:
					No_2_Leftright();
					break;
				case 3:
					No_3_Right90();
					break;
				case 4:
					No_4_Left90();
					break;
				case 5:
					No_5_Powerset();
					break;
				case 6:
					No_6_Powerset_Reverse();
					break;
				}
			}

		}
		print(original);

	}

}
